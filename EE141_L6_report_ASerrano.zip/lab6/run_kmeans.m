%This program is modified by Norton Kishi from the original code from TA
%Alex
clear all; clc; close all;
rng(0);
load('mnist_train.mat')
[idx, C] = kmeans(data,3,'replicates',5); %use for problem 2 and onward
datat = data';
figure; hold on;
%Problem 1
%imshow(reshape((datat(:,1)),[28,28]));hold on; %1/3 type %1
%imshow(reshape((datat(:,2)),[28,28]));hold on; %2/3 type %7
%imshow(reshape((datat(:,3)),[28 28]));%3/3 type %6

%Problem 2.1
%imshow(reshape(C(1,:),[28 28]));  %7
%imshow(reshape(C(2,:),[28 28]));  %6
%imshow(reshape(C(3,:),[28 28]));  %1

%Problem 2.2 and 2.3
%the functions only find the first iteration of all three cases
% [error,correct] = c_c(idx, labels);
% [index,idx_data,labels_data] = find_err_c1(idx,labels);
% figure;
% imshow(reshape((datat(:,index)),[28,28])); hold on;
% [i,idx_i,labels_i] = find_err_c2(idx,labels);
% figure;
% imshow(reshape((datat(:,i)),[28,28])); hold on;
% [ind, idx_ind, labels_ind] = find_err_c3(idx,labels);
% figure;
% imshow(reshape((datat(:,ind)),[28,28]));

%Problem 3
load('mnist_test.mat'); bmin = [0,0,0]; idx_test = [312,1];
for j=1:312
    bmin(:,1)=norm(data_test(j,:)-C(1,:));
    bmin(:,2)=norm(data_test(j,:)-C(2,:));
    bmin(:,3)=norm(data_test(j,:)-C(3,:));
    [M I] = min(vectorize(bmin));
    idx_test(j) = I;
end
clear ans;%for some reason, whenever I run my code, ans becomes a 1x312 char array of all boxes...
vectorize(idx_test);
[error,correct] = c_c(idx_test, labels_test);
[index,idx_data,labels_data] = find_err_c1(idx_test,labels_test);
figure; imshow(reshape((data_test(index,:)),[28,28])); hold on;
[i,idx_i,labels_i] = find_err_c2(idx_test,labels_test);
figure; imshow(reshape((data_test(i,:)),[28,28])); hold on;
[ind, idx_ind, labels_ind] = find_err_c3(idx_test,labels_test);
figure; imshow(reshape((data_test(ind,:)),[28,28])); hold on;



