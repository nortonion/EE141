clear all; clc; close all;
rng(0);
load('mnist_test.mat')
[idx, C] = kmeans(data_test,3,'replicates',5);
data_tt = data_test';

%Problem 3
%imshow(reshape(C(1,:),[28 28])); %7
%imshow(reshape(C(2,:),[28 28])); %6
%imshow(reshape(C(3,:),[28 28])); %1
