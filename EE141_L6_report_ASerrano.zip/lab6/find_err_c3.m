function [index,idxi,labelsi] = find_err_c3(x,y)
%find error of c1 cluster if exists
%   find error of c1 cluster if exists
%x = idx, y = labels
for i=1:length(x)
    if(x(i) == 3 && y(i) ~= 1)
        index = i;
        idxi = x(i);
        labelsi = y(i);
    end
end
end

