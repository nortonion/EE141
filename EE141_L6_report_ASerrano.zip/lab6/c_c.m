function [error,correct] = err(x,y)
%UNTITLED3 Compares the data labels of idx to labels and computes error
%   Compares the data labels of idx to labels and computes error
error = 0;
correct = 0;
for i=1:length(x)
    if(x(i)==1 && y(i)==7)
        correct = correct + 1;
    end
    if(x(i)==2 && y(i)==6)
        correct = correct + 1;
    end
    if(x(i)==3 && y(i)==1)
        correct = correct + 1;
    end
end
error = 1 - (correct/length(x));
end

