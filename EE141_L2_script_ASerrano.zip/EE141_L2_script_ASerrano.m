%The code below is for Question 2.
A = [1,0,0,-1,-1,0,0;-1,1,0,0,0,0,0;0,0,1,1,0,-1,-1;0,1,1,0,0,0,0;1,0,0,0,0,0,0;0,0,0,1,0,1,1];
b = [-100;-100;0;40;100;100];
augmented = [A,b];
rref(augmented);
%to see the individual matrices A, b, augmented, or row reduced echelon
%form, please take off the semicolon ";"

%The code below is for Question 3
A3 = [0,1,1,0,0,-1;-1,0,1,-1,0,0;-1,0,0,0,1,1,;0,1,0,1,1,0];
b3 = [80;30;50;100];
augment = [A3,b3];
rref(augment);
%to see the individual matrices A, b, augmented, or row reduced echelon
%form, please take off the semicolon ";"

%This code below is if the assumption that t = 100 from question 2 still
%holds, and is the solution if this is the desired result that Alex is
%looking for.
altA = [0,1,1,0,0,-1;-1,0,1,-1,0,0;-1,0,0,0,1,1,;0,1,0,1,1,0;0,0,1,0,0,0]
altb = [80;30;50;100;100]
altaug = [altA, altb]
rref(altaug)
%to see the individual matrices A, b, augmented, or row reduced echelon
%form, please take off the semicolon ";"

%Please use discretion when grading this lab. Thank you.