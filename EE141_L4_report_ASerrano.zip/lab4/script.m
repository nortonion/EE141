%Hello remove \% if needed%
clc; clear all; close all;
load('bunny.mat')


%% Visualize PC
% figure;
% S = diag([0.1 0.1 0.1]);%Q1 Part 1
% scatter3(P(1,:), P(2,:), P(3,:),3,Color,'filled');
% Pnew = S * P;
% figure;
% scatter3(Pnew(1,:), Pnew(2,:), Pnew(3,:),3,Color,'filled');%Q1 Part 1

%Below is Q1 Part 2
s2 = diag([1 1 0]);
sp2 = diag([1 1 0.2]);
spart2 = diag([1 1 5]);
spt2 = diag([1 1 -1]);
Pnt = s2 * P;
%Pnt = sp2 * P;
%Pnt = spart2 * P;
%Pnt = spt2 * P;
figure;
hold on;
scatter3(P(1,:), P(2,:), P(3,:),3,[1 0 0],'filled');
scatter3(Pnt(1,:), Pnt(2,:), Pnt(3,:),3,[0 0 1],'filled');
hold off;
axis tight;
grid on;
legend('Original PC','Modified PC');

% %Question 2 part 1
% %P_rot_1 = rotate_first_axis(P,45);
% %P_rot_2 = rotate_second_axis(P,45);
% P_rot_3 = rotate_third_axis(P,45);
% figure;
% hold on;
% scatter3(P_rot_1(1,:), P_rot_1(2,:), P_rot_1(3,:),20,repmat([1 0 0], [size(P,2),1]),'filled');
% %scatter3(P_rot_2(1,:), P_rot_2(2,:), P_rot_2(3,:),20,repmat([1 0 0], [size(P,2),1]),'filled');
% scatter3(P_rot_3(1,:), P_rot_3(2,:), P_rot_3(3,:),20,repmat([1 0 0], [size(P,2),1]),'filled');
% scatter3(P(1,:), P(2,:), P(3,:),20, repmat([0 0 1], [size(P,2),1]),'filled');
% hold off;
% axis tight;
% grid on;
% legend('Rotated Along First Axis','Original');

% %Question 2 Part 3
% Pn1 = rotate_first_axis(P,30);
% Pn2 = rotate_first_axis(Pn1,30);
% Pn3 = rotate_first_axis(P,60);
% figure;
% hold on;
% scatter3(P(1,:), P(2,:), P(3,:),20, repmat([0 0 1], [size(P,2),1]),'filled');
% hold on;
% scatter3(Pn2(1,:), Pn2(2,:), Pn2(3,:),20, repmat([1 0 0], [size(P,2),1]),'filled');
% hold on;
% scatter3(Pn3(1,:), Pn3(2,:), Pn3(3,:),20, repmat([0 1 0], [size(P,2),1]),'filled');
% legend('Original','R_1(phi)[R_1(theta)P]','R_1(phi + theta)P');

% %Question 2 Part 4
% Pn4 = rotate_second_axis(P,45);
% Pn5 = rotate_first_axis(Pn4,40);
% Pn6 = rotate_first_axis(P,40);
% Pn7 = rotate_second_axis(Pn6, 45);
% figure;
% hold on;
% scatter3(Pn5(1,:), Pn5(2,:), Pn5(3,:),20, repmat([0 1 0], [size(P,2),1]),'filled');
% scatter3(Pn7(1,:), Pn7(2,:), Pn7(3,:),20, repmat([1 0 0], [size(P,2),1]),'filled');
% scatter3(P(1,:), P(2,:), P(3,:),20, repmat([0 0 1], [size(P,2),1]),'filled');
% legend('R_1(phi)[R_2(theta)P]','R_2(theta)[R_1(phi)P]','Original');

% %Question 3 Part 1,2,3
% p_out = pointcloud_modification(P);
% p_assist = rotate_second_axis(P,-20);
% iden = eye(3);
% e1 = iden(:,1);
% e2 = iden(:,2);
% e3 = iden(:,3);
% a1 = pointcloud_modification(e1);
% a2 = pointcloud_modification(e2);
% a3 = pointcloud_modification(e3);
% A = [a1,a2,a3];
% Pn8 = A * P;
% figure;
% hold on;
% scatter3(p_out(1,:), p_out(2,:), p_out(3,:),20, repmat([0 0 1], [size(P,2),1]),'filled');
% scatter3(p_assist(1,:), p_assist(2,:), p_assist(3,:),20, repmat([1 0 0], [size(P,2),1]),'filled');
% scatter3(Pn8(1,:), Pn8(2,:), Pn8(3,:),20, repmat([1 0 1], [size(P,2),1]),'filled');
% scatter3(P(1,:), P(2,:), P(3,:),20, repmat([0 1 0], [size(P,2),1]),'filled');
% legend('PC using pointcloud function','Assisted PC','PC using A matrix','Original');

xlabel('x axis');
ylabel('y axis');
zlabel('z axis');
%%


