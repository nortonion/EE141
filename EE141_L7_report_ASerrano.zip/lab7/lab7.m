clear all; clc; close all;
load('temp_data.mat');

%Problem 4.1
figure;
plot(daily_temp);

%Problem 4.3
[A, b] = giveAb(daily_temp(1:5844),7);
%%A^T*A*beta = A^T*b
inv_A_t_A = inv((A')*A);
beta = inv_A_t_A * A' * b;

%Problem 4.4
figure;
plot(b); legend("b");
figure;
plot(A*beta); legend("predicted temperature");
figure;
plot(A*beta-b); %xlim([0,365]);
legend("error");

%Problem 5.1
[C,d] = giveAb(daily_temp(5838:6210),7);
pred2016 = C*beta;
err2016 = pred2016-d;
figure; plot(d); legend("true temperature");
figure; plot(pred2016); legend("predicted temp for 2016");
figure; plot(err2016); legend("error between actual/predicted 2016");

%Problem 6.1
for j = 1:10
    [G, h] = giveAb(daily_temp(1:5844), j);
    N6 = length(daily_temp(1:5844));
    Atrans = G'*G;
    beta_pred = inv(Atrans)*(G' * h);
    fin_error(j) = norm((G * beta_pred)-h)^2/(N6 - j);
end
figure; plot(fin_error);

%Problem 6.2
for q = 1:10
    [G_new, h_new] = giveAb(daily_temp(1:5844), q);
    Atran = (G_new)'*G_new;
    beta_p = inv(Atran)*((G_new)' * h_new);
    [C6, d6] = giveAb(daily_temp(5838:6210),q);
    err_fin(q) = (norm((C6 * beta_p)-d6)^2)/366;
end
figure; plot(err_fin); ylim([0.22,0.4]);


