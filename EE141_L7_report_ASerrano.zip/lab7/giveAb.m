function [A,b] = giveAb(x,B)
%Given a vector x and a parameter B, yields A and b.
%   Given a vector and a parameter B, yields A and b.
N = length(x);
A = zeros(N-B,B);
for w = 1:B
    for q = 1:(N-B)
        A(q,w) = x(B - w + q, 1);
    end
end
for c = 1: N - B
    b(c,1) = x(B+c);
end

end

