function [x_thresholded, K] = v_t(x,p)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
%thresholding code
%This is the modified version of x_thresholding function that Alex
%gave us. 
n=length(x);
K = round(p*n);


magnitude = abs(x);

sorted_magnitude = sort(magnitude,'descend');

value_K_largest =  sorted_magnitude(K);% value of the K-th largest entry of x

x_thresholded = x;

for i=1:n
    
   if( abs(x(i)) <  value_K_largest)
       
       x_thresholded(i) = 0; 
       
   end
    
    

end

