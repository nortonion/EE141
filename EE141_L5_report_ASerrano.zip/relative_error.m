function [ e ] = relative_error( X_compressed, X_original )
%computes relative error between two images

e = norm(X_compressed - X_original,'fro');
e = e/norm(X_original,'fro');

end

