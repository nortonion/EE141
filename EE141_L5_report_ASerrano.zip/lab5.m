clear all; clc; close all;
X = im2double(rgb2gray(imread('picture.tiff')));
Xblock = X(1:32,1:32);
xblock = Xblock(:);
T = DCT_for_vectorized_images(32);%P1.3
check = inv(T);%P1.3
chq = inv(T) * T;%P1.3
cheq = T * inv(T);%P1.3
err = matrix_error(eye(1024),chq);%P1.3
error = matrix_error(eye(1024),cheq);%P1.3
y = T * xblock;
figure;
stem(y); hold on; xlim([0,1024]); ylim([-3,13]);
xlabel("# of data entries");
ylabel("Value of data entries");

%Problem 2 is in v_t.m

%Problem 3
yblock = y;
[toptwenty, value] = v_t(yblock,0.2);
figure;
stem(toptwenty); hold on; xlim([0,1024]); ylim([-3,13]);
xlabel("# of data entries");
ylabel("Value of data entries");
%notice that check did the T^-1 earlier for us
%toptwenty is the y tilda in the decoding portion
rresult = check * toptwenty;
res = reshape(rresult,[32 32]);
imshow(res); %shows the resulting image of this lab process

%P3.3 5%
[topfive, vfive] = v_t(yblock,0.05);
stem(topfive); hold on; xlim([0,1024]); ylim([-3,13]);xlabel("# of data entries"); 
ylabel("Value of data entries");
rfivep = check * topfive;
resfivep = reshape(rfivep, [32 32]);
imshow(resfivep);
relefivep = relative_error(Xblock, resfivep);

%P3.3 10%
[topten, vten] = v_t(yblock, 0.1);
stem(topten); hold on; xlim([0,1024]); ylim([-3,13]);xlabel("# of data entries"); 
ylabel("Value of data entries");
rtenp = check * topten;
restenp = reshape(rtenp, [32 32]);
imshow(restenp);
reletenp = relative_error(Xblock, restenp);

%P3.3 30%
[topthirty, vthirty] = v_t(yblock, 0.3);
stem(topthirty); hold on; xlim([0,1024]); ylim([-3,13]);xlabel("# of data entries"); 
ylabel("Value of data entries");
rthirtyp = check * topthirty;
resthirtyp = reshape(rthirtyp, [32 32]);
imshow(resthirtyp);
relethirtyp = relative_error(Xblock, resthirtyp);

%P3.3 50%
[topfifty, vfifty] = v_t(yblock, 0.5);
stem(topfifty); hold on; xlim([0,1024]); ylim([-3,13]);xlabel("# of data entries"); 
ylabel("Value of data entries");
rfiftyp = check * topfifty;
resfiftyp = reshape(rfiftyp, [32 32]);
imshow(resfiftyp);
relefiftyp = relative_error(Xblock, resfiftyp);

%Problem 4
Y = dct2(X);
y = Y(:);
[top_y, vtop_y] = v_t(y,0.2);
stem(top_y); hold on; xlabel("# of data entries"); ylabel("Value of data entries");
square_again = reshape(top_y, [512 512]);
square_result = idct2(square_again);
imshow(square_result);
rele_y = relative_error(X, square_result); 

%Problem 4 0.1%
[top_pone, vtop_pone] = v_t(y,0.001);
stem(top_pone); hold on; xlabel("# of data entries"); ylabel("Value of data entries");
square_agai = reshape(top_pone, [512 512]);
square_resul = idct2(square_agai);
imshow(square_resul);
rele_pone = relative_error(X, square_resul); 

%Problem 4 1%
[top_one, vtop_one] = v_t(y,0.01);
stem(top_one); hold on; xlabel("# of data entries"); ylabel("Value of data entries");
square_aga = reshape(top_one, [512 512]);
square_res = idct2(square_aga);
imshow(square_res);
rele_one = relative_error(X, square_res); 

%Problem 4 5%
[top_faive, vtop_five] = v_t(y,0.05);
stem(top_faive); hold on; xlabel("# of data entries"); ylabel("Value of data entries");
square_rep = reshape(top_faive, [512 512]);
square_duh = idct2(square_rep);
imshow(square_duh);
rele_duh = relative_error(X, square_duh); 

%Problem 4 10%
[top_ju, vtop_ju] = v_t(y,0.1);
stem(top_ju); hold on; xlabel("# of data entries"); ylabel("Value of data entries");
square_repet = reshape(top_ju, [512 512]);
square_noduh = idct2(square_repet);
imshow(square_noduh);
rele_noduh = relative_error(X, square_noduh); 
