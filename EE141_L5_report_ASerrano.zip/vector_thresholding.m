%thresholding code
n= 20;
K = 5;
vector = randn(n,1);


magnitude = abs(vector);

sorted_magnitude = sort(magnitude,'descend');

value_K_largest =  % value of the K-th largest entry of vector

vector_thresholded = vector;

for i=1:n
    
   if( abs(vector(i)) <  )
       
       vector_thresholded(i) = 
       
   end
    
    
end