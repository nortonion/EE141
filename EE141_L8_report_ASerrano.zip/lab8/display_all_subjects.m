%display images

clear;
load('yale_data.mat');
number_subjects = 15;
number_faces =11;

subject_faces = [];

for i=1:number_subjects
   
    index_of_subject_face = i*11; %%%complete this 
    current_face = reshape(faces(:,index_of_subject_face),64,64);
    subject_faces = [subject_faces,current_face];
    
end

%Problem 2.2
CC = covariance(faces);
[V,D] = eigs(CC,10);

%Problem 2.3
eig_faces = [];
for j=1:10
    cur_eig_face = reshape(V(:,j),64,64);
    eig_faces = [eig_faces,cur_eig_face];
end

%Problem 2.4
eigen_faces=[];
[Vc,Dc] = eigs(CC,20);
for jj=11:20
    ima_eig_face = reshape(Vc(:,jj),64,64);
    eigen_faces = [eigen_faces,ima_eig_face];
end
dd = diag(Dc);
%figure;
%plot(dd); ylim([0,2500000]);

%Problem 3.1
A = faces(:,122:132); %Subject 11
Ca = covariance(A);
B = faces(:,56:66); %Subject 5
Cb = covariance(B);

%Problem 3.2
[Va, Da] = eigs(Ca,5);
[Vb, Db] = eigs(Cb,5);
eigeig_faces = []; dem_faces = [];
for mm=1:5
    current_eig_face = reshape(Va(:,mm),64,64);
    eigeig_faces = [eigeig_faces,current_eig_face];
end
for mmm=1:5
    c_eig_face = reshape(Vb(:,mmm),64,64);
    dem_faces = [dem_faces,c_eig_face];
end

%Problem 3.3
AB = [A B];
Cab = covariance(AB);
[Vab, Dab] = eigs(Cab, 5);
dese_faces = [];
for index=1:5
    cc_eig_face = reshape(Vab(:,index),64,64);
    dese_faces = [dese_faces,cc_eig_face];
end

%imagesc(subject_faces); %Problem 2.1
%imagesc(eig_faces); %Problem 2.2, 2.3
%imagesc(eigen_faces); %Problem 2.4
%imagesc(eigeig_faces); %Problem 3.2 subject a
%imagesc(dem_faces); %Problem 3.2 subject b
imagesc(dese_faces); %Problem 3.3 subject ab
axis equal; %This screws up the plot for Problem 2.4
axis tight;
colormap(gray);