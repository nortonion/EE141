function [covar] = covariance(X)
%Creates the covariance matrix given a set of m dimensional vectors stored
%in size X
%   Detailed explanation goes here
[m,n] = size(X);
X_avg = (1/n)*sum(X,2);

Y=zeros(m,1);
covar=zeros(m,m);
for i=1:n
    Y = X(:,i)-X_avg;
    covar = covar + (Y*Y');
end

covar = (1/n)*covar;

end

