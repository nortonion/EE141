clear all; close all; clc;
filename = 'picture.tiff'; %this is the name of an image in your current folder
fmt = 'tiff';               %image format, e.g. jpe, png, tiff, 
im = imread(filename, fmt);

imGray = rgb2gray(im);

[m, n] = size(imGray); %matrix imGray has m rows, and n columns

% %extracting an image block using indices
%  starti = floor(m/2)+1;
%  endi = floor(starti + m/4)-1;
% 
% startj = 1;
%  endj = floor(startj +n/4)-1;
%  
%  block = imGray(starti:endi, startj:endj);
%  zero_padded_block = uint8(zeros(m,n));
%  zero_padded_block(starti:endi,startj:endj) = block;

%extracting many image blocks using a for loop
 block_size = 128;
 IndicesI = 1:block_size:m;
 nI = length(IndicesI);

 for t=1:nI
    
      starti = IndicesI(t);
     endi   = starti + block_size-1;
     endi   = min(endi,m);
     block  = imGray(1:n,starti:endi);
     %transposed the imGray because we want to have blocks show up
     %vertically quarterly
     zero_padded_block = uint8(zeros(m,n));
     zero_padded_block(1:m, starti:endi) = block;
     
     figure;
     %imshow(block);
     imshow(zero_padded_block);
     title(['Block #', num2str(t),' of size ',num2str(size(block),3),'x',num2str(size(block,2))]);
     %the title function allows us to mention what the images in each
     %figure are.
 end

%Extracting squared blocks using nested for loops

% block_size = 256;
% IndicesI = 1:block_size:m;
% IndicesJ = 
% nI = length(IndicesI);
% nJ = 
% for t=1:nI
%     for s=1:nJ
%         starti = IndicesI(t);
%         endi   = starti + block_size-1;
%         endi   = min(endi,m);
%         
%         startj = 
%         endj   = 
%         endj   = 
%         block  = imGray(,);
%         zero_padded_block = uint8(zeros(m,n));
%         zero_padded_block(,) = block;
%         
%         figure;
%         %imshow(block);
%         imshow(zero_padded_block);
%         
%     end
% end
% 
% 
% 
% 
