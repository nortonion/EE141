%hello, uncomment blocks of code that you want to check as needed.%
clear all; close all; clc;
load("network2.mat");
alpha = 0.85
T = ones(803,803)/803;
U (1:803,1:1)= 0;
U(1,1) = 1;

%Part 1
P = alpha * S + (1-alpha) * T;

%Part 2
uk = U;
for t=1:30 %for part 3, we changed 10 to 30. Feel free to try it out for yourself :)
    uk = P * uk;
    U = [U uk];
end

%Part 4
uprime = sort(U(:,11),'descend');%descend makes it much easier because you don't have to scroll.