%hello, uncomment blocks of code that you want to check as needed.%
clear all; close all; clc;
load("network1.mat");
T = 1/6 * ones(6);

% %Below is the code for part 2 of Problem 2.
% U = transpose([0,0,1,0,0,0]);
% uk = U;
% for t=1:10
%     uk = T * uk;
%     U = [U uk];
% end

% %Below is the code for part 3 of Problem 2.
% U = transpose([1,0,0,0,0,0]);
% uk = U;
% for t=1:10
%     uk = T * uk;
%     U = [U uk];
% end
% 
% %Below is the code for part 4 of Problem 2.
% U = transpose([0,0,0,0,0,1]);
% uk = U;
% for t=1:10
%     uk = T * uk;
%     U = [U uk];
% end

%Below is code for Problem 3
alpha = 0.85;
P = alpha*S_small + (1-alpha)*T;
% %Below is the code for part 2 of Problem 3.
% U = transpose([0,0,1,0,0,0]);
% uk = U;
% for t=1:10
%     uk = P * uk;
%     U = [U uk];
% end

% %Below is the code for part 3 of Problem 3.
% U = transpose([1,0,0,0,0,0]);
% uk = U;
% for t=1:10
%     uk = P * uk;
%     U = [U uk];
% end

% %Below is the code for part 4 of Problem 3.
U = transpose([0,0,0,0,0,1]);
uk = U;
for t=1:10
    uk = P * uk;
    U = [U uk];
end
