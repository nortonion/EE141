%hello, uncomment blocks of code that you want to check as needed.%
clear all; close all; clc;
load("network1.mat");

% %below is the brute force code for part 2 of Problem 1.
% u0 = [0,0,1,0,0,0]';
% u1 = S_small * u0;
% u2 = S_small * u1;
% u3 = S_small * u2;
% u4 = S_small * u3;
% u5 = S_small * u4;
% u6 = S_small * u5;
% u7 = S_small * u6;
% u8 = S_small * u7;
% u9 = S_small * u8;
% u10 = S_small * u9;

% %below is the brute force code for part 3 of Problem 1.
% u0 = transpose([1,0,0,0,0,0]);
% u1 = S_small * u0;
% u2 = S_small * u1;
% u3 = S_small * u2;
% u4 = S_small * u3;
% u5 = S_small * u4;
% u6 = S_small * u5;
% u7 = S_small * u6;
% u8 = S_small * u7;
% u9 = S_small * u8;
% u10 = S_small * u9;

% %Below is the brute force code for part 4 of Problem 1.
% u0 = transpose([0,0,0,0,0,1]);
% u1 = S_small * u0;
% u2 = S_small * u1;
% u3 = S_small * u2;
% u4 = S_small * u3;
% u5 = S_small * u4;
% u6 = S_small * u5;
% u7 = S_small * u6;
% u8 = S_small * u7;
% u9 = S_small * u8;
% u10 = S_small * u9;

% %Below is the code for part 2 of Problem 1.
% U = transpose([0,0,1,0,0,0]);
% uk = U;
% for t=1:10
%     uk = S_small * uk;
%     U = [U uk];
% end

% %Below is the code for part 3 of Problem 1.
% U = transpose([1,0,0,0,0,0]);
% uk = U;
% for t=1:10
%     uk = S_small * uk;
%     U = [U uk];
% end

% %Below is the code for part 4 of Problem 1.
% U = transpose([0,0,0,0,0,1]);
% uk = U;
% for t=1:10
%     uk = S_small * uk;
%     U = [U uk];
% end